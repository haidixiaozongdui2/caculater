// 计算器说明
function showPopup(){
    var overlay = document.getElementById("overlay");
    overlay.style.display = "block";
  }
function hidePopup(){
    var overlay = document.getElementById("overlay");
    overlay.style.display = "none";
}

function cal(num) {
    var n = document.getElementById(num)
    if (n === null) return
    document.getElementById("Screen").value += n.value;
}
 
var flag = true;
function equal() {
    var value = document.getElementById("Screen").value
    
    if (value.indexOf('^') != -1) {
        console.log( value.indexOf('^'))
        value = this.pow(value, value.indexOf('^'))
    }
    //最大公约数
    if (value.indexOf('gcd') != -1) {
        var i=value.indexOf('gcd')
        // console.log(i)
        var value1=value.slice(0,i)
        var value2=value.slice(i+3)
        console.log(i,value1,value2)
        value = this.gcd(value1, value2)
        console.log(value)
        value=String(value)
        // console.log(gcd(value, value.indexOf('g')))
    }

    if (value.indexOf('lcm') != -1) {
        var i=value.indexOf('lcm')
        // console.log(i)
        var value1=value.slice(0,i)
        var value2=value.slice(i+3)
        console.log(i,value1,value2)
        value = this.lcm(value1, value2)
        // console.log(gcd(value, value.indexOf('g')))
    }
    
    // 点击'='切换分数/小数
    if (!flag) {
        document.getElementById("Screen").value = this.decimalToFractional(eval(value))
        flag = true
    } else {
        document.getElementById("Screen").value = eval(value)
        flag = false
    }
}

//求最大公约数
function gcd(a,b){
   if(a%b==0) return b;
   return arguments.callee(b,a%b);
}

//求最小公倍数
function lcm(a,b){
    var num=1
    for(var i=1;i<=a;i++){
        if(a%i==0&&b%i==0){
            num=i
        }
    }
    return a*b/num
}

 
function back() {
    var n = document.getElementById("Screen");
    n.value = n.value.substring(0, n.value.length - 1);
}
 
function clearNum() {
    document.getElementById("Screen").value = "";
}
 
function sin() {
    document.getElementById("Screen").value = Math.sin(document.getElementById("Screen").value);
}
function cos() {
    document.getElementById("Screen").value = Math.cos(document.getElementById("Screen").value);
}
function tan() {
    document.getElementById("Screen").value = Math.tan(document.getElementById("Screen").value);
}
function cot() {
    document.getElementById("Screen").value =1/ Math.tan(document.getElementById("Screen").value);
}
function log() {
    document.getElementById("Screen").value = Math.log(document.getElementById("Screen").value);
}
function mod() {
    document.getElementById("Screen").value = Math.mod(document.getElementById("Screen").value);
}
function sqrt() {
    document.getElementById("Screen").value = Math.sqrt(document.getElementById("Screen").value);
}
function cbrt() {
    document.getElementById("Screen").value = Math.cbrt(document.getElementById("Screen").value)
}
function square() {
    document.getElementById("Screen").value = Math.pow(document.getElementById("Screen").value, 2);
}
function cube() {
    document.getElementById("Screen").value = Math.pow(document.getElementById("Screen").value, 3);
}
function pow(value, pos) {
    if (pos != -1) {
        let arr = value.split("")
        let powVal = Math.pow(arr[pos - 1], arr[pos + 1])
        arr.splice(pos - 1, 3, powVal)
        value = arr.join("")
        return value
    }
}
 
// 阶乘
function factorial() {
    function func(num) {
        if (num == 1) {
            console.log(1);
            return 1;
        } else if (num == 0) {
            console.log(0);
            return 1;
        } else {
            return num * func(num - 1)
        }
    }
    document.getElementById("Screen").value = func(document.getElementById("Screen").value)
}
 
// 小数化为分数
function decimalToFractional(decimal) {
    if (decimal % 1 === 0) {
        return decimal
    }
    const formatDecimal = decimal.toFixed(2)
    let denominator = 100
    let numerator = formatDecimal * 100
    let bigger = 0
    function recursion() {
        bigger = denominator > numerator ? denominator : numerator
        for (let i = bigger; i > 1; i--) {
            if (
                Number.isInteger(numerator / i) && Number.isInteger(denominator / i)) {
                numerator = numerator / i
                denominator = denominator / i
                recursion()
            }
        }
    }
    recursion()
    return `${numerator} / ${denominator}`
}