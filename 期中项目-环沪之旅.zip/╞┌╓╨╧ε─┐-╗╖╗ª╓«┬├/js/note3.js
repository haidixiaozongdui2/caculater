
var tagvalue

function getValue(){    
    var obj = document.getElementsByName("tags");
    console.log(obj)
    console.log(obj.length)
        for(var i=0; i<obj.length; i ++){
            if(obj[i].checked){
                // console.log(obj[i].value);
                tagvalue=obj[i].value;
                // return obj[i].value;
            }
        }
    }
    
document.querySelector('.myconfirm').addEventListener('click',()=>{
        console.log(3);
        getValue();
        console.log(tagvalue);
})


// 提交按钮点击
document.querySelector('.mybtn').addEventListener('click',()=>{

        
        var dic=new Map()
        var money=document.querySelector(".num").value;
        console.log(money);
        var note=document.querySelector(".beizhu").value;
        console.log(note);
        var today= new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //一月是0！ 
        var yyyy = today.getFullYear();
        today= yyyy+'-'+mm + '-' + dd ; 


        var arr=JSON.parse(window.localStorage.getItem('myarr'))

        dic['index']=arr.length+1
        dic['tags']=tagvalue
        dic['money']=money
        dic['note']=note
        dic['time']=today

        console.log(arr)

        arr.push(dic)

        console.log(arr)

        window.localStorage.setItem('myarr',JSON.stringify(arr))
})
    