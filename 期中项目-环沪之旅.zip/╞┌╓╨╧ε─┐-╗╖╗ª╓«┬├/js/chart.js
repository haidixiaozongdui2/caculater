
        var w = window.innerWidth
            || document.documentElement.clientWidth
            || document.body.clientWidth;
        var h = window.innerHeight
            || document.documentElement.clientHeight
            || document.body.clientHeight;
        
        w = w * 0.98;
        h = h * 0.98;
        //定义画布
        var svg = d3.select("body")
                    .append("svg")
                    .attr("width", w)
                    .attr("height", h);
        //定义变量
        var dataset = new Array(53);
        dataset = [3.7, 4.1, 4.6, 4.9, 5.4, 6.0, 7.3, 9.1, 10.4, 12.2, 15.2, 17.2, 18.9, 22.1, 27.2, 35.6, 48.5, 60.4, 70.8,
            78.8, 83.8, 89.4, 99.1, 109.3, 120.5, 136.6, 161.4, 186.0, 219.0, 270.7, 321.2, 347.9, 410.4, 483.4, 537.3, 588.1,
            642.1, 683.4, 737.1, 820.1, 896.9, 986.5, 1016.0];
        var txt = ["1978年", " ", " ", "  ", "1982年", " ", " ", " ", "1986年", " ", " ", " ",
            "1990年", " ", " ", " ", "1994年", " ", " ", " ", "1998年", " ", " ", " "," 2002年",
            "", "", "", "2006年", "", " ", " ", "2010年", " ", " ", " ", "2014年", " ",
            " ", " ", "2018年", " ", "2020年"];
 
        var color = d3.scale.category20();
        
        svg.selectAll("rect")
            .data(dataset)
            .enter()
            .append("rect")
            .attr("x", function (d, i) { return i * w / dataset.length; })
            .attr("y", function (d) { return (h - 0.5 * d) - 20; })
            .attr("width", function(d){ return 0.9 * w / dataset.length ; })
            .attr("height", function (d) { return 0.5*d; })
            .attr("fill", color);
        svg.selectAll("text")
            .data(dataset)
            .enter()
            .append("text")
            .attr("fill", "#4682B4")
            .attr("font-size", "14px")
            .attr("text-anchor", "middle")
            .attr("x", function (d, i) { return i * w / dataset.length+15; })
            .attr("y", function (d) { return (h - 0.5 * d) - 30; })
            .text(function (d) { return d; });
 
        bar1 = svg.append("g").attr("class", "bar1");
        var l = dataset.length;
        bar1.selectAll("text").data(txt).enter().append("text").attr("fill", "black")
            .attr("font-size", "12px").attr("text-anchor", "middle")
            .attr("x", function (d,i) { return i * w / l+18; })
            .attr("y", function (d) { return h ; })
            .text(function (d) { return d; });
        //添加标题
        svg.append("text").attr("font-size", "24px")
            .attr("text-anchor", "middle").attr("x", w / 2).attr("y", 50).text("1978年至2020年全国国内生产总值");
        svg.append("text").attr("font-size", "14px")
            .attr("x", w/2+50).attr("y", 80).text("（单位：千亿元）"); 
