// var budget=0
// window.localStorage.getItem('myarr')
// var arr=JSON.parse(window.localStorage.getItem('myarr'))
// console.log(arr)

// console.log(budget)

// localStorage.clear()


var pay=0
var todaypay=0
var budget
// window.localStorage.setItem('mybudget',JSON.stringify(budget))
// window.localStorage.setItem('mypay',JSON.stringify(pay))

// var text=document.createElement("p")
// console.log(text)
// budget=JSON.parse(window.localStorage.getItem('mybuget'))
// var content=document.createTextNode(`${budget}`)
// text.appendChild(content);
// console.log(text)
// var container=document.getElementById("budget");
// container.appendChild(text)


//  console.log(budget)

// localStorage.clear()

// 渲染记账
var arr=JSON.parse(window.localStorage.getItem('myarr'))
console.log(arr)
const htmlarr=arr.map(item=>{
    return `<tr class="box">
    <td>${item.index}</td>
    <td>${item.tags}</td>
    <td>${item.money}</td>
    <td>${item.note}</td>
    <td>${item.time}</td>
</tr>`
}).join('')
console.log(htmlarr)
document.querySelector('.record').innerHTML=htmlarr

// 总支出
for(var i=0;i<arr.length;i++)
{
   pay+=Number(arr[i]['money'])
}
console.log(pay)
var text4=document.createElement("p")
var content4=document.createTextNode(`${pay}`)
text4.appendChild(content4);
console.log(text4)
var container4=document.getElementById("pay");
container4.appendChild(text4)

// 今日支出
var today= new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //一月是0！ 
var yyyy = today.getFullYear();
today= yyyy+'-'+mm + '-' + dd ; 

for(var i=0;i<arr.length;i++)
{
    if(arr[i]['time']==today)
    todaypay+=Number(arr[i]['money'])
}
console.log(todaypay)
var text5=document.createElement("p")
var content5=document.createTextNode(`${todaypay}`)
text5.appendChild(content5);
console.log(text5)
var container5=document.getElementById("todaypay");
container5.appendChild(text5)

// 当前时间
var timetext="当前时间:"+today
var text6=document.createElement("span")
var content6=document.createTextNode(`${timetext}`)
text6.appendChild(content6);
var container6=document.getElementById("timetext");
container6.appendChild(text6)

    
//  弹框
const modalDom=document.querySelector('.mybox')
const modal=new bootstrap.Modal(modalDom)

// 弹框显示
document.querySelector('.btn-edit').addEventListener('click',()=>{
    modal.show()
})

// 重新开始
document.querySelector('.btn-restart').addEventListener('click',()=>{
     var arr=[]
     window.localStorage.setItem('myarr',JSON.stringify(arr))
})

// 弹框保存
document.querySelector('.save-btn').addEventListener('click',()=>{
    var budget=document.querySelector('.budget').value
    console.log(budget)
    starttime=document.querySelector('.starttime').value
    endtime=document.querySelector('.endtime').value

    var text=document.createElement("span")
    console.log(budget)
    var content=document.createTextNode(`${budget}`)
    text.appendChild(content);
    console.log(text)
    var container=document.getElementById("budget");
    container.appendChild(text)

    // 日期
    var today= new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //一月是0！ 
    var yyyy = today.getFullYear();
    today= yyyy+'-'+mm + '-' + dd ; 
    console.log(today)
    console.log(endtime)

    let date2 =new Date(today)
    let date1 =new Date(endtime)
    let daysBetween = getDaysBetweenDates(date1, date2);
    console.log(daysBetween); // 输出: 

    // 剩余日均
    var dayremain=(budget-pay)/daysBetween
    dayremain=dayremain.toFixed(2); 
    var text2=document.createElement("span")
    var content2=document.createTextNode(`${dayremain}`)
    // var id=document.createAttribute("id")
    // id.value="dayremain"
    text2.appendChild(content2);
    // text2.appendChild(id);
    console.log(text2)
    var container2=document.getElementById("remain");
    container2.appendChild(text2)


    // 打印剩余天数
    var text3=document.createElement("span")
    var daybetweentext=+daysBetween+"天"
    var content3=document.createTextNode(`${daybetweentext}`)
    text3.appendChild(content3);
    console.log(text3)
    var container3=document.getElementById("day");
    container3.appendChild(text3)

    modal.hide()
})

function getDaysBetweenDates(date1, date2) {
    let oneDay = 24 * 60 * 60 * 1000;
    let diffDays = Math.round(Math.abs((date1 - date2) / oneDay));
    return diffDays;
  }


